/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.trabalho1.controller;

import br.com.trabalho1.controller.dao.AlunoDAOJsonImpl;
import br.com.trabalho1.view.TelaGradeHorariosFrame;

/**
 *
 * @author 07155422908
 */
public class ControladorPrincipal {
    
    private AlunoDAOJsonImpl alunoDAOJsonImpl;
    private TelaGradeHorariosFrame frame;
    
    
}
