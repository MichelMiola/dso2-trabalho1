 
package br.com.trabalho1.model;

import java.util.ArrayList;
import java.util.List;

 
public class Grade {
    
    private Integer diaSemana;
    private List<Horario> horarios = new ArrayList<>();
    
    
}
