 
package br.com.trabalho1.model;

 
public class Horario {
    
    private Integer linha;
    private Disciplina diciplina;
    
}
